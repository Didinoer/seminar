import * as React from "react";
// import { useRouter } from "next/router";
import { Link, useNavigate, useLocation} from "react-router-dom";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import QrCodeScannerIcon from "@mui/icons-material/QrCodeScanner";
import HistoryIcon from "@mui/icons-material/History";
import ConfirmationNumberIcon from "@mui/icons-material/ConfirmationNumber";
// import Link from "next/link";
// import styled from 'styled-components';

// const StyledLink = styled(Link)`
//     text-decoration: none;

//     &:focus, &:hover, &:visited, &:link, &:active {
//         text-decoration: none;
//     }
// `;

export default function DrawerItems() {
//   const router = useNavigate();
  const location = useLocation();

  return (
    <React.Fragment>
      <Link to={"/orders"} className="text-link">
        <ListItemButton selected={location.pathname === "/orders"}>
          <ListItemIcon>
            <ShoppingCartIcon />
          </ListItemIcon>
          <ListItemText primary="Orders" />
        </ListItemButton>
      </Link>
      <Link to={"/tickets"} className="text-link">
        <ListItemButton selected={location.pathname === "/tickets"}>
          <ListItemIcon>
            <ConfirmationNumberIcon />
          </ListItemIcon>
          <ListItemText primary="Tickets" />
        </ListItemButton>
      </Link>
      <Link to={"/scanner"} className="text-link">
        <ListItemButton selected={location.pathname === "/scanner"}>
          <ListItemIcon>
            <QrCodeScannerIcon />
          </ListItemIcon>
          <ListItemText primary="Scanner" />
        </ListItemButton>
      </Link>
      <Link to={"/history"} className="text-link">
        <ListItemButton selected={location.pathname === "/history"}>
          <ListItemIcon>
            <HistoryIcon />
          </ListItemIcon>
          <ListItemText primary="History" />
        </ListItemButton>
      </Link>
    </React.Fragment>
  );
}