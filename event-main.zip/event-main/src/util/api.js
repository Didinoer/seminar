// const API_URL = "http://localhost:8000/";
const API_URL = "https://inspirafest.id/server/";
const bearerToken = "Bearer " + localStorage.getItem("token");

export async function login(credentials) {
  const response = await fetch(`${API_URL}api/login`, {
    method: "POST",
    body: JSON.stringify(credentials),
    headers: {
      "Content-Type": "application/json",
    },
  });

  const data = await response.json();
  console.log(data);

  if (!response.ok) {
    throw new Error(data.message || "Something went wrong!");
  }

  return data;
}

export async function logout() {
  const response = await fetch(`${API_URL}api/logout`, {
    method: "POST",
    body: null,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });

  const data = await response.json();
  console.log(data);

  if (!response) {
    if (response.status === 401) {
      return response;
    }
    throw new Error(data.message || "Something went wrong!");
  }

  return data;
}

export async function checkToken() {
  const response = await fetch(`${API_URL}api/check-token`, {
    method: "POST",
    body: null,
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });

  const data = await response.json();
  console.log(data);

  if (!response) {
    if (response.status === 401) {
      return response;
    }
    throw new Error(data.message || "Something went wrong!");
  }

  return data;
}

export async function getAllOrders(params) {
  const response = await fetch(
    `${API_URL}api/orders?` + new URLSearchParams(params),
    {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: bearerToken,
      },
    }
  );
  const result = await response.json();

  if (!result.success) {
    throw new Error(result.message || "Something went wrong!");
  }

  const orders = result.data;

  return orders;
}

export async function getAllOrderTotal() {
  const response = await fetch(`${API_URL}api/orders/total`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();

  if (!result.success) {
    throw new Error(result.message || "Something went wrong!");
  }

  const orders = result.data;

  return orders;
}

export async function getInvoice(invoiceCode) {
  const response = await fetch(`${API_URL}api/orders/${invoiceCode}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();

  if (!result.success) {
    throw new Error(result.message || "Something went wrong!");
  }

  const order = result.data.order;

  return order;
}

export async function getAllTickets(params) {
  const response = await fetch(
    `${API_URL}api/tickets?` + new URLSearchParams(params),
    {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: bearerToken,
      },
    }
  );
  const result = await response.json();

  if (!result.success) {
    console.log(result);
    throw new Error(result.message || "Something went wrong!");
  }

  const tickets = result.data;

  return tickets;
}

export async function getAllTicketTotal() {
  const response = await fetch(`${API_URL}api/tickets/total`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();

  const tickets = result.data;

  return tickets;
}

export async function getAllTicketSummaryTotal() {
  const response = await fetch(`${API_URL}api/tickets/summary`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();

  const tickets = result.data;

  return tickets;
}

export async function getAllHistories(params) {
  const response = await fetch(
    `${API_URL}api/history?` + new URLSearchParams(params), {
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: bearerToken,
      },
    }
  );
  const result = await response.json();

  const histories = result.data;

  return histories;
}

export async function getTicket(ticketCode) {
  const response = await fetch(`${API_URL}api/tickets/code/${ticketCode}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();
  console.log(result);
  const tickets = result.data.tickets;
  console.log(tickets);

  return tickets;
}

export async function submitCheckIn(ticketArray) {
  const response = await fetch(`${API_URL}api/tickets/checkin`, {
    method: "POST",
    body: JSON.stringify(ticketArray),
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();
  console.log(result);
  if (!result.success) {
    console.log(result);
    throw new Error(result.message || "Something went wrong!");
  }
  const tickets = result.data;

  return tickets;
}

export async function getTicketsByInvoiceCode(invoiceCode) {
  const response = await fetch(`${API_URL}api/tickets/${invoiceCode}`, {
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
      Authorization: bearerToken,
    },
  });
  const result = await response.json();

  console.log(result);

  if (!result.success) {
    throw new Error(result.message || "Something went wrong!");
  }

  const tickets = result.data.tickets;

  return tickets;
}
